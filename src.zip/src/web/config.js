const config = {
  // apiUrl: 'http://localhost:3000'
  apiUrl: 'http://localhost:3510'
};

export default config;